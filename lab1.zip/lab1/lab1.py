import streamlit as st
import pandas as pd
import seaborn as sns
from matplotlib import pyplot as plt

# Charger les données
data = pd.read_csv('BeansDataSet.csv')

# Standardiser la colonne 'Channel' pour éviter les problèmes de casse ou d'espaces
data['Channel'] = data['Channel'].str.strip().str.capitalize()

# Interface Streamlit
st.sidebar.title('Navigation')
menu = st.sidebar.selectbox('Choisir un volet', ['Accueil', 'Aperçu des données', 'Analyse des ventes', 'Visualisations', 'Rapport et recommandations'])

# Page d'accueil
if menu == 'Accueil':
    st.markdown(
        """
        <div style='text-align: center;'>
        <h1> Analyse des ventes de Beans & Pods </h1>
        </div>
        """,
        unsafe_allow_html=True
    )
    st.write("Bienvenue dans l'application d'analyse des ventes de Beans & Pods. Cette application explore les données de ventes pour identifier des tendances et fournir des recommandations marketing.")
    st.dataframe(data.head())

# Aperçu des données
elif menu == 'Aperçu des données':
    st.subheader('Aperçu des données')
    st.write("10 premières lignes :")
    st.dataframe(data.head(10))
    st.write("10 dernières lignes :")
    st.dataframe(data.tail(10))
    st.write("Statistiques descriptives :")
    st.dataframe(data.describe())
    st.write("Répartition par canal :")
    st.write(data['Channel'].value_counts())
    st.write("Répartition par région :")
    st.write(data['Region'].value_counts())

# Analyse des ventes
elif menu == 'Analyse des ventes':
    st.header('Analyse des ventes')
    produits = ['Robusta', 'Arabica', 'Espresso', 'Lungo', 'Latte', 'Cappuccino']
    
    st.subheader('Ventes totales par produit')
    ventes_par_produit = data[produits].sum()
    st.bar_chart(ventes_par_produit)

    st.subheader('Ventes par canal')
    ventes_par_canal = data.groupby('Channel')[produits].sum()
    st.dataframe(ventes_par_canal)

    st.subheader('Ventes par région')
    ventes_par_region = data.groupby('Region')[produits].sum()
    st.dataframe(ventes_par_region)

# Visualisations
elif menu == 'Visualisations':
    st.header('Visualisations')
    produits = ['Robusta', 'Arabica', 'Espresso', 'Lungo', 'Latte', 'Cappuccino']
    
    st.subheader('Histogramme des ventes par produit')
    data[produits].hist(figsize=(15, 10), bins=20, layout=(2, 3))
    st.pyplot(plt.gcf())
    plt.clf()

    st.subheader('Corrélation entre produits')
    fig_corr, ax_corr = plt.subplots(figsize=(10, 8))
    sns.heatmap(data[produits].corr(), annot=True, cmap='coolwarm', fmt='.2f', ax=ax_corr)
    st.pyplot(fig_corr)
    plt.clf()

    st.subheader('Ventes par canal (graphique)')
    fig_canal, ax_canal = plt.subplots(figsize=(10, 6))
    data.groupby('Channel')[produits].sum().plot(kind='bar', ax=ax_canal)
    ax_canal.set_ylabel('Ventes')
    st.pyplot(fig_canal)
    plt.clf()

    st.subheader('Ventes par région (graphique)')
    fig_region, ax_region = plt.subplots(figsize=(10, 6))
    data.groupby('Region')[produits].sum().plot(kind='bar', ax=ax_region)
    ax_region.set_ylabel('Ventes')
    st.pyplot(fig_region)
    plt.clf()

# Rapport et recommandations
else:
    st.title("Rapport et recommandations")
    produits = ['Robusta', 'Arabica', 'Espresso', 'Lungo', 'Latte', 'Cappuccino']
    
    # Calculs pour le rapport
    total_ventes = data[produits].sum().sum()
    ventes_par_produit = data[produits].sum()
    produit_top = ventes_par_produit.idxmax()
    ventes_par_canal = data.groupby('Channel')[produits].sum().sum()

    # Débogage : Vérifier les index de ventes_par_canal
    st.write("Index de ventes_par_canal :", ventes_par_canal.index.tolist())

    # Utiliser .get() pour éviter KeyError
    ventes_online = ventes_par_canal.get('Online', 0)
    ventes_store = ventes_par_canal.get('Store', 0)
    pourcentage_online = (ventes_online / total_ventes) * 100 if total_ventes > 0 else 0
    pourcentage_store = (ventes_store / total_ventes) * 100 if total_ventes > 0 else 0

    ventes_par_region = data.groupby('Region')[produits].sum().sum()
    region_top = ventes_par_region.idxmax()

    st.write("### Résultats de l'analyse")
    st.write(f"- **Ventes totales** : {int(total_ventes)} unités vendues au total.")
    st.write(f"- **Produit le plus vendu** : {produit_top} avec {int(ventes_par_produit[produit_top])} unités.")
    st.write(f"- **Canaux** : Les ventes en ligne représentent {pourcentage_online:.1f}% ({int(ventes_online)} unités), contre {pourcentage_store:.1f}% ({int(ventes_store)} unités) en magasin.")
    st.write(f"- **Région dominante** : La région {region_top} génère le plus de ventes avec {int(ventes_par_region[region_top])} unités.")
    
    st.write("### Recommandations pour la campagne marketing")
    st.write(f"- **Cibler la région South** : Cette région domine largement les ventes (97% des transactions). Investissez dans des promotions locales sur {produit_top}.")
    st.write(f"- **Renforcer la présence en ligne** : Avec {pourcentage_online:.1f}% des ventes via le canal en ligne, augmentez les efforts sur le marketing digital (publicités sur les réseaux sociaux, SEO).")
    st.write("- **Offres combinées** : Les produits Espresso et Latte montrent une corrélation positive (voir matrice de corrélation). Proposez des bundles Espresso+Latte pour augmenter les ventes croisées.")
    st.write("- **Focus sur les best-sellers** : Mettez en avant Espresso et Latte, qui dominent les ventes de gousses, dans vos campagnes.")

    st.write("### Données supplémentaires à collecter")
    st.write("- **Données démographiques** : Âge, sexe des clients pour mieux segmenter les campagnes.")
    st.write("- **Saisonnalité** : Dates des ventes pour identifier les périodes de pointe.")
    st.write("- **Coût par produit** : Pour calculer les marges et optimiser les promotions.")
    
    st.write("Lien GitHub : [insérer lien vers le dépôt].")