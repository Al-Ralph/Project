import streamlit as st
from database import init_db, register_user, login_user, add_image, search_similar_images
from extraction import extract_features
from reconnaissance import facial_login_static, facial_login_realtime
from PIL import Image

def main():
    st.title("Application d'Authentification et CBIR")
    init_db()

    if 'logged_in' not in st.session_state:
        st.session_state.logged_in = False
        st.session_state.username = None
        st.session_state.stop_webcam = False
        st.session_state.recognition_time = 0

    # Menu de la navbar (sidebar)
    menu = ["Accueil", "Inscription", "Connexion Classique", "Connexion Réseaux Sociaux", "Connexion Faciale", "Connexion Webcam"] if not st.session_state.logged_in else ["Accueil", "Ajouter Image", "Rechercher Image", "Déconnexion"]
    choice = st.sidebar.selectbox("Menu", menu)

    if choice == "Accueil":
        if st.session_state.logged_in:
            st.write(f"Bienvenue, {st.session_state.username} !")
        else:
            st.write("Bienvenue ! Veuillez vous connecter ou vous inscrire.")

    elif choice == "Inscription":
        st.subheader("Créer un nouveau compte")
        username = st.text_input("Nom d'utilisateur")
        email = st.text_input("Email")
        password = st.text_input("Mot de passe", type="password")
        face_image = st.file_uploader("Photo pour reconnaissance faciale (optionnel)", type=["jpg", "png"])
        if st.button("S'inscrire"):
            face_encoding = extract_features(face_image) if face_image else None
            if register_user(username, email, password, face_encoding):
                st.success("Inscription réussie !")
            else:
                st.error("Erreur : Nom d'utilisateur déjà pris.")

    elif choice == "Connexion Classique":
        st.subheader("Connexion Classique")
        username = st.text_input("Nom d'utilisateur")
        password = st.text_input("Mot de passe", type="password")
        if st.button("Se connecter"):
            if login_user(username, password):
                st.session_state.logged_in = True
                st.session_state.username = username
                st.success(f"Bienvenue, {username} !")
            else:
                st.error("Identifiants incorrects.")

    elif choice == "Connexion Réseaux Sociaux":
        st.subheader("Connexion via Réseaux Sociaux")
        st.write("Choisissez une méthode de connexion :")
        if st.button("Connexion avec Gmail"):
            st.warning("Connexion Gmail non implémentée (nécessite OAuth). Simulation : utilisateur connecté.")
            st.session_state.logged_in = True
            st.session_state.username = "Utilisateur Gmail"
            st.success("Connexion Gmail simulée !")
        if st.button("Connexion avec Facebook"):
            st.warning("Connexion Facebook non implémentée (nécessite OAuth). Simulation : utilisateur connecté.")
            st.session_state.logged_in = True
            st.session_state.username = "Utilisateur Facebook"
            st.success("Connexion Facebook simulée !")

    elif choice == "Connexion Faciale":
        st.subheader("Connexion par reconnaissance faciale (image)")
        uploaded_file = st.file_uploader("Téléchargez une photo", type=["jpg", "png"])
        if st.button("Se connecter"):
            if uploaded_file:
                image = Image.open(uploaded_file)
                username = facial_login_static(image)
                if username:
                    st.session_state.logged_in = True
                    st.session_state.username = username
                    st.success(f"Bienvenue, {username} !")
                else:
                    st.error("Visage non reconnu.")
            else:
                st.error("Veuillez uploader une image.")

    elif choice == "Connexion Webcam":
        st.subheader("Connexion par webcam")
        if st.button("Démarrer la reconnaissance"):
            username = facial_login_realtime()
            if username:
                st.session_state.logged_in = True
                st.session_state.username = username
                st.success(f"Bienvenue, {username} !")
            else:
                st.error("Aucun utilisateur reconnu.")
        if st.button("Arrêter la webcam"):
            st.session_state.stop_webcam = True

    elif choice == "Ajouter Image" and st.session_state.logged_in:
        st.subheader("Ajouter une image")
        uploaded_file = st.file_uploader("Téléchargez une image", type=["jpg", "png"])
        if st.button("Ajouter"):
            if uploaded_file:
                add_image(st.session_state.username, uploaded_file)
                st.success("Image ajoutée !")
            else:
                st.error("Veuillez uploader une image.")

    elif choice == "Rechercher Image" and st.session_state.logged_in:
        st.subheader("Rechercher des images similaires")
        query_file = st.file_uploader("Téléchargez une image de requête", type=["jpg", "png"])
        if st.button("Rechercher"):
            if query_file:
                image = Image.open(query_file)
                similar_images = search_similar_images(image)
                if similar_images:
                    st.write("Images similaires :")
                    for img_path in similar_images:
                        st.image(img_path, width=200)
                else:
                    st.write("Aucune image similaire trouvée.")
            else:
                st.error("Veuillez uploader une image.")

    elif choice == "Déconnexion" and st.session_state.logged_in:
        st.session_state.logged_in = False
        st.session_state.username = None
        st.session_state.stop_webcam = False
        st.session_state.recognition_time = 0
        st.success("Déconnexion réussie !")

if __name__ == "__main__":
    main()