## Documentation

### Étapes de Développement
Le développement de cette application a suivi plusieurs étapes clés :

1. **Analyse des Exigences** :
   - Objectif : Créer une application d'authentification multi-méthodes avec un système CBIR.
   - Fonctionnalités requises : Authentification classique, via réseaux sociaux (simulée), reconnaissance faciale, et recherche d'images similaires.
   - Contraintes : Utilisation de MySQL pour le stockage, interface web simple, modularité du code.

2. **Conception** :
   - **Architecture Modulaire** : Séparation en quatre fichiers principaux :
     - `database.py` : Gestion de la base de données MySQL.
     - `extraction.py` : Extraction des caractéristiques faciales.
     - `reconnaissance.py` : Reconnaissance faciale (statique et en temps réel).
     - `main.py` : Interface Streamlit et logique principale.
   - **Base de Données** : Création de deux tables dans MySQL :
     - `users` : Stocke les informations des utilisateurs (nom, email, mot de passe haché, encodage facial).
     - `images` : Stocke les chemins des images et leurs histogrammes pour le CBIR.
   - **Technologies** : Choix de Streamlit pour l'interface, `face_recognition` pour la reconnaissance faciale, et OpenCV pour le traitement d'images.

3. **Implémentation** :
   - **Base de Données** : Utilisation de `mysql-connector-python` pour interagir avec MySQL. Les mots de passe sont hachés avec `bcrypt` pour la sécurité.
   - **Authentification Classique** : Implémentée avec un formulaire de connexion (nom d'utilisateur/mot de passe).
   - **Authentification Réseaux Sociaux** : Simulée avec des boutons (Gmail/Facebook), car l'implémentation réelle nécessite OAuth.
   - **Reconnaissance Faciale** :
     - Extraction des encodages faciaux lors de l'inscription avec `face_recognition`.
     - Stockage des encodages dans MySQL.
     - Reconnaissance via image statique ou webcam en comparant les encodages.
   - **CBIR** : Utilisation d'histogrammes de couleurs (calculés avec OpenCV) pour comparer les images.
   - **Interface** : Streamlit pour une interface web simple et interactive.

4. **Tests et Ajustements** :
   - Tests unitaires sur chaque module (ex. connexion MySQL, extraction faciale, CBIR).
   - Ajustements pour la fluidité de la webcam (réduction de l'image pour accélérer la reconnaissance).
   - Suppression de `DeepFace` en raison d'incompatibilités avec TensorFlow/Keras.

5. **Documentation** :
   - Création de ce README avec des instructions claires.
   - Commentaires dans le code pour expliquer les fonctions clés.

### Choix Techniques