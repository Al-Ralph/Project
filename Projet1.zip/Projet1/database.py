import mysql.connector
import bcrypt
import pickle
import cv2
import numpy as np
import os

# Configuration MySQL
DB_CONFIG = {
    'host': 'localhost',
    'user': 'root',  
    'password': '', 
    'database': 'auth_app'
}

def init_db():
    conn = mysql.connector.connect(**DB_CONFIG)
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS users (
                 id INT AUTO_INCREMENT PRIMARY KEY,
                 username VARCHAR(50) UNIQUE,
                 email VARCHAR(100),
                 password BLOB,
                 face_encoding BLOB)''')
    c.execute('''CREATE TABLE IF NOT EXISTS images (
                 id INT AUTO_INCREMENT PRIMARY KEY,
                 username VARCHAR(50),
                 image_path VARCHAR(255),
                 color_histogram BLOB)''')
    conn.commit()
    conn.close()

def hash_password(password):
    return bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt())

def check_password(password, hashed):
    return bcrypt.checkpw(password.encode('utf-8'), hashed)

def register_user(username, email, password, face_encoding=None):
    conn = mysql.connector.connect(**DB_CONFIG)
    c = conn.cursor()
    hashed_password = hash_password(password)
    try:
        c.execute("INSERT INTO users (username, email, password, face_encoding) VALUES (%s, %s, %s, %s)",
                  (username, email, hashed_password, face_encoding))
        conn.commit()
        return True
    except mysql.connector.IntegrityError:
        return False
    finally:
        conn.close()

def login_user(username, password):
    conn = mysql.connector.connect(**DB_CONFIG)
    c = conn.cursor()
    c.execute("SELECT password FROM users WHERE username = %s", (username,))
    result = c.fetchone()
    conn.close()
    if result and check_password(password, result[0]):
        return True
    return False

def get_face_encodings():
    conn = mysql.connector.connect(**DB_CONFIG)
    c = conn.cursor()
    c.execute("SELECT username, face_encoding FROM users WHERE face_encoding IS NOT NULL")
    users = c.fetchall()
    conn.close()
    return [(user[0], pickle.loads(user[1])) for user in users]

def add_image(username, uploaded_file):
    if not os.path.exists("uploads"):
        os.makedirs("uploads")
    file_path = f"uploads/{uploaded_file.name}"
    with open(file_path, "wb") as f:
        f.write(uploaded_file.read())
    hist = cv2.calcHist([cv2.imread(file_path)], [0, 1, 2], None, [8, 8, 8], [0, 256, 0, 256, 0, 256])
    hist = cv2.normalize(hist, hist).flatten()
    hist = pickle.dumps(hist)
    
    conn = mysql.connector.connect(**DB_CONFIG)
    c = conn.cursor()
    c.execute("INSERT INTO images (username, image_path, color_histogram) VALUES (%s, %s, %s)",
              (username, file_path, hist))
    conn.commit()
    conn.close()
    return file_path

def search_similar_images(query_file):
    query_image = cv2.cvtColor(np.array(query_file), cv2.COLOR_RGB2BGR)
    query_hist = cv2.calcHist([query_image], [0, 1, 2], None, [8, 8, 8], [0, 256, 0, 256, 0, 256])
    query_hist = cv2.normalize(query_hist, query_hist).flatten()

    conn = mysql.connector.connect(**DB_CONFIG)
    c = conn.cursor()
    c.execute("SELECT image_path, color_histogram FROM images")
    results = c.fetchall()
    conn.close()

    similar_images = []
    for image_path, stored_hist in results:
        stored_hist = pickle.loads(stored_hist)
        distance = cv2.compareHist(query_hist, stored_hist, cv2.HISTCMP_CHISQR)
        if distance < 50:
            similar_images.append(image_path)
    return similar_images