import face_recognition
import cv2
import numpy as np
import streamlit as st
from database import get_face_encodings

def facial_login_static(uploaded_file):
    encodings_list = get_face_encodings()
    signatures = [enc for _, enc in encodings_list]
    noms = [name for name, _ in encodings_list]
    
    image = np.array(uploaded_file)
    image_rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
    uploaded_encodings = face_recognition.face_encodings(image_rgb)
    
    if not uploaded_encodings:
        return None
    
    uploaded_encoding = uploaded_encodings[0]
    for nom, signature in zip(noms, signatures):
        distance = face_recognition.face_distance([signature], uploaded_encoding)[0]
        if distance < 0.6:
            return nom
    return None

def facial_login_realtime():
    encodings_list = get_face_encodings()
    signatures = [enc for _, enc in encodings_list]
    noms = [name for name, _ in encodings_list]
    
    capture = cv2.VideoCapture(0)
    stframe = st.empty()
    recognized_user = None
    recognition_start_time = None
    recognition_duration = 5  # Durée en secondes pour confirmer la reconnaissance
    
    while True:
        ret, image = capture.read()
        if not ret:
            st.error("Erreur : Impossible de lire la vidéo.")
            break

        image_reduit = cv2.resize(image, (0, 0), fx=0.25, fy=0.25)
        image_reduit_rgb = cv2.cvtColor(image_reduit, cv2.COLOR_BGR2RGB)
        emplacement_face = face_recognition.face_locations(image_reduit)
        carac_face = face_recognition.face_encodings(image_reduit, emplacement_face)

        current_user = None
        for encode, loc in zip(carac_face, emplacement_face):
            match = face_recognition.compare_faces(signatures, encode)
            distanceFace = face_recognition.face_distance(signatures, encode)
            minDist = np.argmin(distanceFace)
            y1, x2, y2, x1 = loc
            y1, x2, y2, x1 = y1 * 4, x2 * 4, y2 * 4, x1 * 4

            if match[minDist]:
                nom = noms[minDist]
                cv2.rectangle(image, (x1, y1), (x2, y2), (0, 255, 0), 4)
                cv2.putText(image, nom, (x1, y1 - 25), cv2.FONT_HERSHEY_COMPLEX, 1, (255, 255, 255), 2)
                current_user = nom
            else:
                nom = 'Inconnu'
                cv2.rectangle(image, (x1, y1), (x2, y2), (0, 0, 255), 4)
                cv2.putText(image, nom, (x1, y1 - 25), cv2.FONT_HERSHEY_COMPLEX, 1, (255, 0, 0), 2)

        # Gestion de la reconnaissance persistante
        if current_user:
            if recognized_user == current_user:
                # Si le même utilisateur est reconnu, vérifie la durée
                if recognition_start_time is None:
                    recognition_start_time = st.session_state.get("recognition_time", 0)
                    st.session_state.recognition_time = recognition_start_time + 1
                elif st.session_state.recognition_time - recognition_start_time >= recognition_duration:
                    # Si l'utilisateur est reconnu pendant 5 secondes, on le connecte
                    capture.release()
                    return current_user
            else:
                # Nouvel utilisateur détecté, réinitialise le timer
                recognized_user = current_user
                recognition_start_time = None
                st.session_state.recognition_time = 0
        else:
            # Aucun utilisateur reconnu, réinitialise
            recognized_user = None
            recognition_start_time = None
            st.session_state.recognition_time = 0

        stframe.image(image, channels="BGR")
        if st.session_state.get("stop_webcam", False):
            break
    
    capture.release()
    return None  