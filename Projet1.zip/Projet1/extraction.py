import face_recognition
import cv2
import numpy as np
import pickle

def extract_features(image_file):
    """
    Extrait les caractéristiques faciales d'une image.
    
    Args:
        image_file: Fichier image (Streamlit UploadedFile ou numpy array).
    
    Returns:
        bytes: Encodage facial sérialisé (ou None si aucun visage détecté).
    """
    if isinstance(image_file, np.ndarray):
        image = image_file
    else:
        image = face_recognition.load_image_file(image_file)
    image_rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
    encodings = face_recognition.face_encodings(image_rgb)
    if not encodings:
        return None
    return pickle.dumps(encodings[0])